create
    definer = root@localhost procedure register_user(IN p_username varchar(50), IN p_password varchar(100),
                                                     IN p_role varchar(20))
BEGIN
    INSERT INTO users(username, password, role)
    VALUES(p_username, p_password, p_role);
END;

