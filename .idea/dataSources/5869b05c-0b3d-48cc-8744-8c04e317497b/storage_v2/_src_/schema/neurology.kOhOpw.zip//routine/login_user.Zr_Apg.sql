create
    definer = root@localhost procedure login_user(IN p_username varchar(50), IN p_password varchar(100))
BEGIN
    SELECT COUNT(*) AS user_exists
    FROM users
    WHERE username = p_username AND password = p_password;
END;

